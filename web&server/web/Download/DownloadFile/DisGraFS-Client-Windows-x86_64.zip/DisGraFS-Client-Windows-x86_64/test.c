#include <stdio.h>

int main(void)
{
    printf("HW!");
    char a[100];
    scanf("%s", a);
    printf("%s", a);
    return 0;
}
